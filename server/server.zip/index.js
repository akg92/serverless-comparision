const impl = require('./impl');
const provider = require('./provider');
const providerType = 'GCP';

exports.handler = async (event,context,callback) => {
    // TODO implement
    

    var cloudHandler = provider.getProvider(providerType,event,context,callback);
    var query = cloudHandler.getQueryParam("name");
    var response = null;
    switch(query){
        
        case "add":
            //response = await impl.add();
            var a = new Date().getTime();
            response = String(a)
            break;
        case "request":
            response = await impl.request();
    }

    // write the response
    cloudHandler.writeResponse(response);
};
